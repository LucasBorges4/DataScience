import cv2
import numpy as np

def extrairMaiorCtn(img):
    imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    imgTh = cv2.adaptiveThreshold(imgGray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 12)
    kernel = np.ones((2,2), np.uint8)
    imgDil = cv2.dilate(imgTh,kernel)
    contours,hi = cv2.findContours(imgDil,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)

    maiorCtn = max(contours, key = cv2.contourArea)
    angulo = cv2.fitEllipse(maiorCtn)
    print(angulo[2])
    if ((angulo[2] >5) or (angulo[2] <5)):
        #criando matrix para rotação
        M = cv2.getRotationMatrix2D((int(imgDil.shape[0]/2),int(imgDil.shape[1]/2)), -53, 1.0)
        #aplicando a rotação
        imagem_rotacionada = cv2.warpAffine(imgDil, M, (imgDil.shape[1], imgDil.shape[0]))
        cv2.imshow("recorte",imagem_rotacionada)
        cv2.waitKey(0)
        contours,hi = cv2.findContours(imagem_rotacionada,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
        maiorCtn = max(contours, key = cv2.contourArea)
    x,y,w,h = cv2.boundingRect(maiorCtn)
    bbox = [x,y,w,h]
    recorte = img[y:y+h,x:x+w]
    recorte = cv2.resize(recorte,(400,500))
    cv2.imshow("recorte",recorte)
    cv2.waitKey(0)

    return recorte,bbox
